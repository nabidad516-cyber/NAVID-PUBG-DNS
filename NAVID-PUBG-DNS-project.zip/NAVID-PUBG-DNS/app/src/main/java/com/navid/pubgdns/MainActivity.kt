package com.navid.pubgdns

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL

private val Bg = Color(0xFF090611)
private val Purple = Color(0xFFB45CFF)
private val Muted = Color(0xFFB9A9C9)

data class DnsServer(val name: String, val url: String, var ms: Long? = null)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NavidApp() }
    }
}

@Composable
fun NavidApp() {
    val scope = rememberCoroutineScope()
    var testing by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("آماده آزمایش") }
    var best by remember { mutableStateOf("هنوز آزمایش نشده") }
    var results by remember {
        mutableStateOf(listOf(
            DnsServer("Cloudflare", "https://cloudflare-dns.com/dns-query"),
            DnsServer("Google", "https://dns.google/resolve?name=example.com&type=A"),
            DnsServer("Quad9", "https://dns.quad9.net/dns-query")
        ))
    }

    fun runTest() {
        testing = true
        status = "در حال آزمایش پاسخ DNS..."
        scope.launch {
            val tested = withContext(Dispatchers.IO) {
                results.map { server ->
                    val elapsed = probe(server.url)
                    server.copy(ms = elapsed)
                }.sortedBy { it.ms ?: Long.MAX_VALUE }
            }
            results = tested
            best = tested.firstOrNull { it.ms != null }?.let { "${it.name} — ${it.ms} ms" }
                ?: "پاسخی دریافت نشد"
            status = "آزمایش تمام شد"
            testing = false
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Purple, background = Bg, surface = Color(0xFF171020)
    )) {
        Column(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(listOf(Color(0xFF1A0B2B), Bg, Color(0xFF090611)))
            ).padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(24.dp))
            Text("NAVID", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold, letterSpacing = 5.sp)
            Text("PUBG DNS", color = Purple, fontSize = 30.sp, fontWeight = FontWeight.Black)
            Text("آزمایش تأخیر پاسخ DNS", color = Muted, fontSize = 13.sp)
            Spacer(Modifier.height(28.dp))
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF21132F)),
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(status, color = Muted)
                    Spacer(Modifier.height(8.dp))
                    Text(best, color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(16.dp))
                    Button(
                        onClick = { runTest() },
                        enabled = !testing,
                        colors = ButtonDefaults.buttonColors(containerColor = Purple),
                        modifier = Modifier.fillMaxWidth().height(54.dp)
                    ) {
                        Text(if (testing) "در حال آزمایش..." else "شروع تست DNS", fontSize = 17.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
            Spacer(Modifier.height(24.dp))
            Text("سرورهای آزمایشی", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.Start))
            Spacer(Modifier.height(10.dp))
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(results) { server ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF171020)),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(Modifier.padding(16.dp).fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(server.name, color = Color.White, fontWeight = FontWeight.Bold)
                                Text("آزمایش HTTPS DNS", color = Muted, fontSize = 12.sp)
                            }
                            Text(server.ms?.let { "$it ms" } ?: "—", color = Purple, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            Text(
                "توجه: این عدد زمان پاسخ DNS است، نه پینگ داخل مسابقه پابجی.",
                color = Muted, fontSize = 11.sp
            )
        }
    }
}

private fun probe(address: String): Long? {
    return try {
        val url = if (address.contains("cloudflare-dns")) {
            URL("$address?name=example.com&type=A")
        } else URL(address)
        val start = System.nanoTime()
        val connection = (url.openConnection() as HttpURLConnection).apply {
            connectTimeout = 5000
            readTimeout = 5000
            requestMethod = "GET"
            setRequestProperty("Accept", "application/dns-json")
        }
        val code = connection.responseCode
        if (code in 200..299) {
            connection.inputStream.use { it.readBytes() }
            ((System.nanoTime() - start) / 1_000_000).coerceAtLeast(1)
        } else null.also { connection.disconnect() }
    } catch (_: Exception) { null }
}
